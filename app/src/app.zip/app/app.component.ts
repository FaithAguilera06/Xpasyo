import { Component, OnInit } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular/standalone';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { FirebaseService } from './services/firebase.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [IonApp, IonRouterOutlet],
})
export class AppComponent implements OnInit {
  constructor(private firebaseService: FirebaseService, private router: Router) {}

  ngOnInit() {
    const auth = getAuth();
    onAuthStateChanged(auth, async (user: User | null) => {
      if (user) {
        const role = await this.firebaseService.getUserRole(user.uid);
        if (role === 'client') {
          this.router.navigate(['/client/home']);
        } else if (role === 'coach') {
          this.router.navigate(['/coach/coach-home']);
        } else {
          // Unknown role, redirect to login or landing
          this.router.navigate(['/login']);
        }
      } else {
        // Not logged in, redirect to login
        this.router.navigate(['/login']);
      }
    });
  }
}
